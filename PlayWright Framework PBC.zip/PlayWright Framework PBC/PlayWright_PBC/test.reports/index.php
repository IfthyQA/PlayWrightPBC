<!DOCTYPE html>
<html>
<head>
<title>Test Automation Reports </title>
<style>
a{
	display: block;
	font-size: 16px;
	line-height: 20px;
	margin-bottom: 5px;
}
h2{
  font-size: 16px;
}
h2.italic {
  font-style: italic;
}
</style>
</head>
<body>
<h1>Regression Suite - Test Automation Reports </h1>
<h2 class="italic">*Folders Format (YYYYMMDD-HHmm)*</h2>
<?php
if ($handle = opendir('.')) {
$blacklist = array('.', '..', 'ScreenShots', 'index.php');
$files = array();
while (false !== ($folder = readdir($handle))) {
if (!in_array($folder, $blacklist)) {
$files[] = $folder;
}
}
foreach(array_reverse($files) as $file) {
echo "<a href=$file>".$file."</a>";
}
closedir($handle);
}
?>
</body>
</html>

