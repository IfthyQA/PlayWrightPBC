package baseClass;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.LoadState;
import screenShot.EventList;
import java.io.IOException;
import org.testng.annotations.*;

public class BaseTest {
    protected Playwright playwright;
    protected Browser browser;
    protected BrowserContext context;
    protected static Page page;

    @BeforeClass
    public void setUp() throws IOException, InterruptedException {
        // Ensure any previous browser instance is closed
        try (Playwright playwright = Playwright.create()) {
            playwright.close();
        }
        Runtime.getRuntime().exec("taskkill /F /IM chrome.exe /T");

        /* Initializing the Browser */
        System.out.println("Initializing Playwright and Browser...");

        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
        context = browser.newContext(new Browser.NewContextOptions().setViewportSize(1920, 1080));
        page = context.newPage();  // ✅ Page is now initialized

        // ✅ Now, set the Page instance in EventList
        EventList.setPage(page);  

        page.navigate("about:blank");
        page.waitForLoadState(LoadState.NETWORKIDLE);
        System.out.println("Browser launched successfully!");
    }
    

    @BeforeMethod
    public void navigateToHomePage() throws IOException, InterruptedException {
        if (page == null) {
            System.out.println("Page is null. Reinitializing...");
            setUp(); // Relaunch the Browser 
        }

        page.navigate("https://www.personalbrandingcouncil.com/");
        page.waitForLoadState(LoadState.LOAD);

        // Verify Home Page Title
        String expectedTitle = "AI Agent-driven Professional Development and Hiring Platform | ACHNET";
        String actualTitle = page.title();

        if (!actualTitle.equals(expectedTitle)) {
            System.out.println("Homepage did not load correctly. Retrying...");
            setUp();
            navigateToHomePage();
        } else {
            System.out.println("Homepage Landed Successfully: Testing Continues!");
        }
    }

    @AfterMethod
    public void verifyLogout() {
    	
        // Verify Logout Successful
        String expectedLogoutTitle = "AI Agent-driven Professional Development and Hiring Platform | ACHNET";
        String actualLogoutTitle = page.title();

        if (actualLogoutTitle.equals(expectedLogoutTitle)) {
            System.out.println("Logout successful. Test case PASSED.");
        } else {
            System.out.println("Logout FAILED.");
        }
    }

    @AfterClass
    public void tearDown() {
        if (browser != null) {
            browser.close();
        }
        if (playwright != null) {
            playwright.close();
        }
        System.out.println("All tests are completed. Cleaned up resources.");
    }
}



