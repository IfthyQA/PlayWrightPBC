package reportEmail;

import java.io.File;
import java.nio.file.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.testng.annotations.Test;

public class HtmlReport {

    private final String reportsDir = "C:\\Users\\dev\\eclipse-workspace\\PlayWright_PBC\\test.reports\\";
    private final String from = "support@personalbrandingcouncil.com";
    private final String password = "Rockon$459";

    private final String[] recipients = {
        "neeraj.chaudhary@tescra.com",
        "achnetteam@tescra.com"
    };

    @Test
    public void sendHtmlReportEmail() throws InterruptedException {
        // Get the latest report folder
        String latestFolder = getRecentFolder(reportsDir);
        if (latestFolder == null) {
            System.out.println("No report folders found.");
            return;
        }

        // Construct the index.html file path
        Path indexHtmlPath = Paths.get(latestFolder, "html", "overview.html");
        File indexFile = indexHtmlPath.toFile();

        if (!indexFile.exists()) {
            System.out.println("overview.html file not found in the latest report folder.");
            return;
        }

        // Extract and parse HTML content
        String emailBody = parseAndGenerateTable(indexFile);

        // Send email
        sendEmailWithHtmlBody(emailBody);
    }

    private String getRecentFolder(String dirPath) {
        File dir = new File(dirPath);
        File[] folders = dir.listFiles(File::isDirectory);

        if (folders == null || folders.length == 0) return null;

        Arrays.sort(folders, Comparator.comparingLong(File::lastModified).reversed());
        return folders[0].getAbsolutePath();
    }

    private static String parseAndGenerateTable(File file) throws InterruptedException {
        try {
            Document doc = Jsoup.parse(file, "UTF-8");
            List<List<String>> outputTable = new ArrayList<>();
            boolean titleEntered = false;
            Elements Overview = doc.getElementsByClass("overviewTable");

            for (Element OverviewTab : Overview) {
                Elements Columns = OverviewTab.getElementsByClass("columnHeadings");
                if (Columns.isEmpty()) continue;

                String ColumnName = Columns.text();
                String[] ColumnSplit = ColumnName.trim().split("\\s+");

                if (!titleEntered) {
                    List<String> Titles = new ArrayList<>();
                    Titles.add("Suite_Name");
                    Titles.addAll(Arrays.asList(ColumnSplit));

                    int lastIndex = Titles.size() - 1;
                    if (lastIndex > 0) {
                        Titles.remove(lastIndex);
                        Titles.set(lastIndex - 1, "Pass_Rate");
                    }
                    outputTable.add(Titles);
                    titleEntered = true;
                }

                Elements Rows2 = OverviewTab.getElementsByClass("test");
                if (Rows2.isEmpty()) continue;

                String RowsName = Rows2.text();
                String link = Rows2.get(0).getElementsByAttribute("href").attr("href");
                String[] RowsSplit = RowsName.trim().split("\\s+");

                if (RowsSplit.length > 0) {
                    RowsSplit[0] = "<a href=\"" + link + "\">" + (RowsSplit[0].isEmpty() ? "SuiteName" : RowsSplit[0]) + "</a>";
                }

                List<String> currRowElements = new ArrayList<>();
                for (String currRow : RowsSplit) {
                    currRowElements.add(currRow);
                    if (currRowElements.size() == outputTable.get(0).size()) break;
                }
                outputTable.add(currRowElements);
            }

            if (outputTable.isEmpty()) {
                return "<p>No test data found.</p>";
            }

            Thread.sleep(2000);

            String table = "<style>"
                    + "table { font-family: arial, sans-serif; border-collapse: collapse; width: 100%; }"
                    + "td, th { border: 1px solid #dddddd; text-align: left; padding: 8px; }"
                    + "tr:nth-child(even) { background-color: #dddddd; }"
                    + "</style>";

            table += "<br><h1><center> PlayWright Regression Suite - Automation Test Report </center></h1><br>";
            table += getHTMLTable(outputTable);

            return table;
        } catch (Exception e) {
            e.printStackTrace();
            return "<p>Error processing HTML file</p>";
        }
    }

    private void sendEmailWithHtmlBody(String htmlContent) {
        Properties props = new Properties();
        props.put("mail.smtp.host", "mail.personalbrandingcouncil.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));

            for (String recipient : recipients) {
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
            }
            message.setSubject("PlayWright Automation Sample HTML Report");

            String emailBody = "<p>Hello Team,</p>"
                    + "<p>The table below is the PlayWright regression suite Recent Modules test results for today. "
                    + "For detailed results, please <a href=\"http://192.168.4.161/index.php/\">click here</a>."
                    + " For previous day's results, <a href=\"http://192.168.4.161/index.php\">click here</a>.</p>"
                    + "<br>-- <br>Thank you,<br>Iftikhar</p>"
                    + "<br>" + htmlContent;

            message.setContent(emailBody, "text/html; charset=utf-8");

            Transport.send(message);
            System.out.println("Email sent successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String getHTMLTable(List<List<String>> tableData) {
        if (tableData == null || tableData.isEmpty()) {
            return "<p>No data available</p>";
        }

        StringBuilder tableHtml = new StringBuilder("<table>");
        
        // Table Header - Apply Grey Background
        tableHtml.append("<tr style='background-color: #dddddd;'>");
        for (String header : tableData.get(0)) {
            tableHtml.append("<th>").append(header).append("</th>");
        }
        tableHtml.append("</tr>");

        // Table Data Rows
        for (int i = 1; i < tableData.size(); i++) {
            tableHtml.append("<tr>");
            for (int j = 0; j < tableData.get(i).size(); j++) {
                String cell = tableData.get(i).get(j);

                if (tableData.get(0).get(j).equals("Pass_Rate")) {
                    if (cell.contains("100")) {
                        tableHtml.append("<td style='background-color:#009900; color: #ffffff;'>").append(cell).append("</td>");
                    } else {
                        tableHtml.append("<td style='background-color:#FF0000; color: #ffffff;'>").append(cell).append("</td>");
                    }
                } else {
                    tableHtml.append("<td>").append(cell).append("</td>");
                }
            }
            tableHtml.append("</tr>");
        }
        tableHtml.append("</table>");
        return tableHtml.toString();
    }
}
