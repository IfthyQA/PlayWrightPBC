package screenShot;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.testng.ITestListener;
import org.testng.ITestResult;
import com.microsoft.playwright.Page;

public class EventList implements ITestListener {
    private static Page page;

    public static void setPage(Page playwrightPage) {
        page = playwrightPage;
    }

    @Override
    public void onTestFailure(ITestResult result) {
        if (page != null) {
            // Create "Screenshots" folder if it does not exist
            File screenshotDir = new File("Screenshots");
            if (!screenshotDir.exists()) {
                screenshotDir.mkdir();
            }

            // Generate timestamp
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
            String timestamp = LocalDateTime.now().format(formatter);

            // Create screenshot filename
            String screenshotName = result.getMethod().getMethodName() + "_" + timestamp + ".png";
            String screenshotPath = "./Screenshots/" + screenshotName;

            // Capture full-page screenshot
            page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(screenshotPath)));

            System.out.println("Screenshot saved at: " + screenshotPath);
        }
        else 
        {
            System.out.println("Page instance is null. Screenshot not taken.");
        }
    }
}

