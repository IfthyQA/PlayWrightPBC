package resume;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.microsoft.playwright.options.LoadState;
import baseClass.BaseTest;


@Listeners
public class Hub extends BaseTest{
	
	@Test
	public void Hub_page() throws InterruptedException {
            // Wait for page to load completely
            page.waitForLoadState(LoadState.NETWORKIDLE);

            // Print the page title
            System.out.println("Page Title: " + page.title());

            // Click the login button
            page.locator("(//button[normalize-space()='Login'])[1]").waitFor();
            page.locator("(//button[normalize-space()='Login'])[1]").click();
            
            // Enter username
            page.waitForSelector("//input[@id='Username']").fill("john.doe001");

            // Enter password
            page.waitForSelector("//input[@id='password-field']").fill("Rockon123");
            page.locator("//input[@id='password-field']").press("Enter");

            // Click the login button
            page.locator("//button[@id='loginButton']").waitFor();
            page.locator("//button[@id='loginButton']").click();           

            // Print success message
            page.locator("//div[contains(text(),'My Profile')]").waitFor();
            System.out.println("Login Successful! Current URL: " + page.url());
            System.out.println("Page Title: " + page.title());
                        
            // Click the Logout 
            page.locator("//div[contains(text(),'My Profile')]").click();          

            page.locator("//div[contains(text(),'Logout')]").waitFor();
            page.locator("//div[contains(text(),'Logout')]").click();           

            // Print success message
            page.locator("(//button[normalize-space()='Login'])[1]").waitFor();
            System.out.println("Logout Successful! Current URL: " + page.url());
            System.out.println("Page Title: " + page.title());
              
	}
}

