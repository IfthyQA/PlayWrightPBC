package resume;

import org.testng.annotations.Test;
import baseClass.BaseTest;

public class Profile extends BaseTest{
		
		@Test
		public void Profile_page() throws InterruptedException {

            // Print the page title
            System.out.println("Page Title: " + page.title());

            // Click the login button
            page.locator("(//button[normalize-space()='Login'])[1]").waitFor();
            page.locator("(//button[normalize-space()='Login'])[1]").click();
            
            // Enter username
            page.waitForSelector("//input[@id='Username']").fill("john.doe001");

            // Enter password
            page.waitForSelector("//input[@id='password-field']").fill("Rockon123");
            page.locator("//input[@id='password-field']").press("Enter");

            // Click the login button
            page.locator("//button[@id='loginButton']").waitFor();
            page.locator("//button[@id='loginButton']").click();  
            
            // Hover over the menu item
            page.locator("//div[@class='menu-item menu-item-active']").waitFor();
            page.locator("//div[@class='menu-item menu-item-active']").hover();

            // Click the submenu item that appears
            page.locator("//div[contains(text(),'Resume')]").waitFor();
            page.locator("//div[contains(text(),'Resume')]").click();

            System.out.println("Successfully hovered and clicked!");

            // Print success message
            System.out.println("Login Successful! Current URL: " + page.url());
            System.out.println("Page Title: " + page.title());
                        
            // Click the Logout 
            page.locator("//div[contains(text(),'My Profile')]").click();          

            page.locator("//div[contains(text(),'Logout')]").waitFor();
            page.locator("//div[contains(text(),'Logout')]").click();           

            // Print success message
            page.locator("(//button[normalize-space()='Login'])[1]").waitFor();
            System.out.println("Logout Successful! Current URL: " + page.url());
            System.out.println("Page Title: " + page.title());               
        }
	}


